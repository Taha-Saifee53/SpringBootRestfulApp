package com.Quantum.restAPI.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.Quantum.resAPI.model.Product;

@RestController
public class ProductServiceController {

	private static Map<String, Product> productRepo = new HashMap<>();

	static {
		Product honey = new Product();
		honey.setId("1");
		honey.setName("Honey");
		honey.setDescription("500gm pack Good for health");
		honey.setPrice("Rs.50");
		productRepo.put(honey.getId(), honey);

		Product almond = new Product();
		almond.setId("2");
		almond.setName("Almond");
		almond.setDescription("500gm pack Good for health");
		almond.setPrice("Rs.500");
		productRepo.put(almond.getId(), almond);
	}

	@RequestMapping(value = "/products/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Object> delete(@PathVariable("id") String id) {
		productRepo.remove(id);
		return new ResponseEntity<>("Product is deleted successsfully", HttpStatus.OK);
	}

	@RequestMapping(value = "/products/{id}", method = RequestMethod.PUT)
	public ResponseEntity<Object> updateproduct(@PathVariable("id") String id, @RequestBody Product product) {
		productRepo.remove(id);
		product.setId(id);
		productRepo.put(id, product);
		return new ResponseEntity<>("Product updated successsfully", HttpStatus.OK);
	}

	@RequestMapping(value = "/products", method = RequestMethod.POST)
	public ResponseEntity<Object> createproduct(@RequestBody Product product) {
		productRepo.put(product.getId(), product);
		return new ResponseEntity<>("Product is created successfully", HttpStatus.CREATED);
	}

	@GetMapping(value = "/AllProducts")
	public ResponseEntity<Object> getAllProducts() {
		System.out.println("HEloo");
		return new ResponseEntity<>(productRepo.values(), HttpStatus.OK);
	}

	@GetMapping(value = "/productsGet")
	public ResponseEntity<Object> getProduct(@RequestBody Map<String, String> body) {

		Product product = new Product();
		boolean flag = false;
		// String notfound1=body.get("Id");
		String found = body.get("Id");
		product.setId(body.get("Id"));
		Map<String, Product> prodRepo1 = new HashMap<String, Product>();
		if (productRepo.containsKey(found) == true) {

			prodRepo1.put(found, productRepo.get(found));

			flag = true;
		} else {
			flag = false;
		}

		if (flag == false) {
			return new ResponseEntity<>("Not Data Found", HttpStatus.OK);
		}

		return new ResponseEntity<>(prodRepo1.values(), HttpStatus.OK);
	}

}
