package com.Quantum.restAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfulserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfulserviceApplication.class, args);
	}

}
